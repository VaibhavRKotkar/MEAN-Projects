import { Directive,ElementRef,HostListener, Input} from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective 
{

  @Input() appHighlight = '';

  constructor(private ele:ElementRef) { }
  @HostListener('mouseenter') onMouseEnter() {
    this.highlight('blue');
    this.highlight(this.appHighlight);
  }
  
  @HostListener('mouseleave') onMouseLeave() {
    this.highlight('');
  }
  
  private highlight(color: string) {
    this.ele.nativeElement.style.color = color;
  }

  }


