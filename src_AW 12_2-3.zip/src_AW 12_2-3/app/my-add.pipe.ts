import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myAdd'
})
export class MyAddPipe implements PipeTransform
 {

  transform(value1: number, param:number): number
   {
   
   var iNo1:number = value1;
   var iNo2:number = param;
   var Sum:number = 0; 

    Sum = iNo1 + iNo2;
   
    return Sum;
  }

}
