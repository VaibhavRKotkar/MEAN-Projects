import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myMult'
})
export class MyMultPipe implements PipeTransform 
{

  transform(value1: number, param:number): number
  {
  
  var iNo1:number = value1;
  var iNo2:number = param;
  var Mult:number = 0; 

   Mult = iNo1 * iNo2;
  
   return Mult;
 }

}
