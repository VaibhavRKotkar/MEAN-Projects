import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marvellous-template',
  templateUrl: './marvellous-template.component.html',
  styleUrls: ['./marvellous-template.component.css']
})
export class MarvellousTemplateComponent implements OnInit 
{
  constructor() { }

  ngOnInit() 
  {
  }
public str=" ";
public str1=" ";

  // Event listener for button
  public AcceptData(value: any)
  {
    console.log(value);
    this.str1 = value;
  }
/*
   public AcceptData(InputData: any)
    {
      console.log(InputData);
      this.str1 = InputData;
    }

*/
  public AcceptInput(value:any)
  {
   this.str = value;
   console.log(value);
  }

  /*
  public AcceptInput(Data:any)
  {
   this.str = Data;
   console.log(Data);
  }

*/
}
