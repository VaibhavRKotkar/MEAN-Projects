import { Component } from '@angular/core';

// import classes which are required for reactive forms
import {FormBuilder,FormGroup,Validators, FormControl, MinLengthValidator, PatternValidator} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent 
{
  // Inject FormBuilder service
  constructor(public fbobj : FormBuilder)
  {
  }
// Disable or unable submit button code:
  buttonDisabled: boolean | undefined;
  ngOnInit()
   {
    this.buttonDisabled = false;
  }
  submit(form: any)
  {
    console.log(form)
  }


// Validators pattern for each form control
  firstnamePattern = "^[A-Za-z -]{3,12}$";
  lastnamePattern = "^[A-Za-z -]{5,10}$";
  pwdPattern = "^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{6,12}$";
  mobnumPattern = "^((\\+91-?)|0)?[0-9]{10}$"; 
  emailPattern = "^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$";
  addressPattern = "^[A-Za-z0-9 _-]{4,25}$";
  cityPattern = "^[A-Za-z -]{4,12}$";
  zipcodePattern = "^[0-9_-]{6}$";
  commentPattern = "^[A-Za-z0-9 _-]{30,100}$";

  CustomerForm = this.fbobj.group(
    {
      // Add Multiple validations
      firstname :['', [Validators.required, Validators.pattern(this.firstnamePattern) ]],
      lastname : ['',[Validators.required, Validators.pattern(this.lastnamePattern)]],
      email :    ['abc@gmail.com',[Validators.required, Validators.pattern(this.emailPattern)]],
      phone :    ['',[Validators.required, Validators.pattern(this.mobnumPattern)]],
      AddressClass : this.fbobj.group(
        {
          address :['',[Validators.required, Validators.pattern(this.addressPattern)]],
          city : ['Enter your city Here..',[Validators.required, Validators.pattern(this.cityPattern)]], 
          state :['Maharashtra'],
         zipcode :['',[Validators.required, Validators.pattern(this.zipcodePattern)]]
        }
      ),
      comments :['',[Validators.required, Validators.pattern(this.commentPattern)]]
    }
  );
  
  // Method to set FormControl fields through program
  SetData()
  {
    this.CustomerForm.setValue(
      {
        firstname : 'Vaibhav',
        lastname : ' ',
        email : 'abc@gmail.com',
        phone : 'abcd',
       
        AddressClass : 
        {
          address : 'Enter permenent address',
          city : 'Enter your city Here...',
          state:'Maharashtra',
          zipcode :'',
          comments : ''
        }
      }
    )
  }
}
