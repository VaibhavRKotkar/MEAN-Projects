import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myrev'
})
export class MyrevPipe implements PipeTransform 
{

  transform(value: string):string
  {
    let str = value;
    let temp:string = "";
   
  
   for (var i = str.length - 1; i >= 0; i--)
    {
       temp = temp + str[i];
   }
  
    return temp;
  }

}
