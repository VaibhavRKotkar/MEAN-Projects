import { Component, OnInit,EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  @Output() public MyEvent = new EventEmitter();

  public AcceptData(value:any)
  {
    this.MyEvent.emit(value);
   
  }
}
