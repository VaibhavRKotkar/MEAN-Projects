import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Demo';

  public data = "";
  public mycolour = "green";
  public colourlen = "Blue";
  public SendData(text:any)
  {
    this.data = text;
  }
}
