import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NumberService {

  iValue: number;

  constructor()
   { 
      this.iValue = 98;
  }

  public ChkPrime()
  {
   
    var iCnt = 0, iCount = 0;

    for(iCnt = 2;iCnt <= (this.iValue/2);iCnt++)
    {
       if((this.iValue % iCnt)==0)
       {
        iCount++;
       }
    }
if(iCount == 0)
{
 return ("Number is Prime Number");
}
else
{
  return ("Number is not a Prime Number");
}
  }
}
