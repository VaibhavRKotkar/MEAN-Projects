import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StringService 
{

  Str: String[50];

  constructor()
   { 
      this.Str = "PIYUSH Sirancha Angular Web Development Class";
  }

  public CountCapital()
  {
   
    var iCnt = 0, iCount = 0;

    for(iCnt = 0;iCnt <= (this.Str.length);iCnt++)
    {
       if((this.Str[iCnt] >= 'A') && (this.Str[iCnt] <= 'Z'))
       {
             iCount++;
       }
    }
    return iCount;
 }
}
