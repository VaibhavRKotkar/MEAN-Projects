import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child',
  template: ` 
   <h2> <font color = "blue"> Check Number is Prime or Not :- </font></h2>

  <h3> <b> Input : 98 </b></h3> 
  <h3> <b> Answer: {{iPrime}} </b></h3> 

<p> -----------------------------------------------------------------
-----------------------------------------</p>
<h2> <font color = "Orange"> Check Capital Letters in String:- </font></h2>

<h3><b>String: ""PIYUSH Sirancha Angular Web Development Class""</b></h3>
<h3><b>Answer: {{ChkSCapital}}</b></h3>
<p> -----------------------------------------------------------------
-----------------------------------------</p>
  `
})

export class ChildComponent implements OnInit
 {

  public iPrime:any;
  public ChkSCapital:any;

  constructor(private _obj1:NumberService, private _obj2:StringService)
   { }

  ngOnInit(): void 
  {
    this.iPrime = this._obj1.ChkPrime();
    this.ChkSCapital = this._obj2.CountCapital();
  }

}
