import { Component, OnInit } from '@angular/core';
import { NumberService } from '../number.service';

@Component({
  selector: 'app-child1',
  template: `
  <h2> <font color = "SlateBlue"> Check Number is Prime or Not :- </font></h2>

  <h3> <b> Input : 11 </b></h3> 
  <h3> <b> Answer: {{iPrime}} </b></h3> 

<p> -----------------------------------------------------------------</p>
  `
  
})
export class Child1Component implements OnInit {

public iPrime:any;
  constructor(private _obj:NumberService)
   { }

  ngOnInit(): void 
  {
    this.iPrime = this._obj.ChkPrime();

  }

}
