import { Component, OnInit } from '@angular/core';
import { StringService } from '../string.service';

@Component({
  selector: 'app-child2',
  template: `
  <h2> <font color = "Tomato"> Check Capital Letters in String:- </font></h2>

  <h3><b>String: "Marvellous Infosystems CLASS"</b></h3>
  <h3><b>Answer: {{ChkSCapital}}</b></h3>
  <p> -----------------------------------------------------------------</p>
  `
 
})
export class Child2Component implements OnInit {

 public ChkSCapital:any;

  constructor(private _obj:StringService ) 
  { }

  ngOnInit(): void 
  {

    this.ChkSCapital = this._obj.CountCapital();
  }

}
