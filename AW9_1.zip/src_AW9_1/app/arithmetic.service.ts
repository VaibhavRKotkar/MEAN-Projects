import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ArithmeticService
 {

  constructor() { }

  public Add()
  {
    var iNo1:number = 11;
    var iNo2:number = 21;
    var iAns:number = 0;

    iAns =iNo1 + iNo2;

    return iAns;

  }
  
  public Sub()
  {
    var iNo1:number = 101;
    var iNo2:number = 45;
    var iAns:number = 0;

    iAns = iNo1 - iNo2;

    return iAns;

  }
}
