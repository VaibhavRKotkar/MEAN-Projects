import { Component, OnInit } from '@angular/core';
import { ArithmeticService } from '../arithmetic.service';

@Component({
  selector: 'app-demo',
  template: `
  <h2>
  <font  color = " Blue">
  Inside Demo Component:
  </font></h2>
  <h2>
  <li>Addition of Two Number is: {{iRetAdd}}</li>
 <li>Substraction of two Number is:  {{iRetSub}}</li>
 </h2>
  `
})
export class DemoComponent implements OnInit {

  public iRetAdd:number = 0;
  public iRetSub:number = 0;
  
  constructor(private _obj:ArithmeticService)
   { }

  ngOnInit(): void
   {
      this.iRetAdd = this._obj.Add();
      this.iRetSub = this._obj.Sub();

  }

}


