import { outputAst } from '@angular/compiler';
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
//import { EventEmitter } from 'protractor';

@Component({
  selector: 'app-subcomponent',
  templateUrl: './subcomponent.component.html',
  styleUrls: ['./subcomponent.component.css']
})
export class SubcomponentComponent implements OnInit 
{
  // Create object of event class
 
 
  // Action listener for button
  
   public message:any = "";
   @Output()eobj = new EventEmitter();

   public SendMessage(str:string)
   {
      this.message = str;
      this.eobj.emit(this.message);
   }
  constructor() { }

  ngOnInit() {
  }

}
