import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'marvellousChk'
})
export class MarvellousChkPipe implements PipeTransform 
{

  transform(value: number, Param:string): string
  
  {
    var No:number = value;
    var Count:number = 0;
    var SumFact:number = 0;
    let str:string = "";
    
    if(Param == "Prime")
    {
      for(var i = 2; i <= (No/2); i++ )
      {
        if(No % i == 0)
        {
          Count++;
        }
      }
        if(Count == 0)
        {
         str ="It is Prime Number";
        }
        else
        {
          str = "It is Not a Prime Number";
        }  
    }

    if(Param == "Perfect")
    {
      for(var i = 1; i <= (No/2); i++ )
      {
        if(No % i == 0)
        {
          SumFact = SumFact + i;
        }
      }
        if(SumFact == No)
        {
         str ="It is Perfect Number";
        }
        else
        {
          str = "It is Not a Perfect Number";
        }
    }


    if(Param == "Even")
    {
     
        if(No % 2 == 0)
        {
         str ="It is Even Number";
        }
        else
        {
          str = "It is Not a Even Number";
        }
    }

    if(Param == "Odd")
    {
     
        if(No % 2 != 0)
        {
         str ="It is Odd Number";
        }
        else
        {
          str = "It is Not a Odd Number";
        }
    }
    return str;
  }
}
