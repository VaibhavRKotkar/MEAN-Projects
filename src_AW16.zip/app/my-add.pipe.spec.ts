import { MyAddPipe } from './my-add.pipe';

describe('MyAddPipe', () => {
  it('create an instance', () => {
    const pipe = new MyAddPipe();
    expect(pipe).toBeTruthy();
  });

  it('Add the numbers', () => {
    let aobj = new MyAddPipe();
    expect(aobj.transform(10,20)).toEqual(30);
  });
});
