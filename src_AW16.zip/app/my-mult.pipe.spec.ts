import { MyMultPipe } from './my-mult.pipe';

describe('MyMultPipe', () => {
  it('create an instance', () => {
    const pipe = new MyMultPipe();
    expect(pipe).toBeTruthy();
  });

  it('Multiplies the numbers', () => {
    let aobj = new MyMultPipe();
    expect(aobj.transform(10,20)).toEqual(200);
  });
});
