import { MarvellousChkPipe } from './marvellous-chk.pipe';

describe('MarvellousChkPipe', () => {
  it('create an instance', () => {
    const pipe = new MarvellousChkPipe();
    expect(pipe).toBeTruthy();
  });

// Check the Prime Number
  it('check the prime', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(11,'Prime')).toEqual("It is Prime Number");
  });

  it('check the prime', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(12,'Prime')).toEqual("It is Not a Prime Number");
  });
// Check the Perfect Number
  it('check the Perfect', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(6,'Perfect')).toEqual("It is Perfect Number");
  });

  it('check the Perfect', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(11,'Perfect')).toEqual("It is Not a Perfect Number");
  });

  // Check the Even Number
  it('check the Even', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(6,'Even')).toEqual("It is Even Number");
  });

  it('check the Even', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(11,'Even')).toEqual("It is Not a Even Number");
  });

   // Check the Odd Number
   it('check the Odd', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(5,'Odd')).toEqual("It is Odd Number");
  });

  it('check the Odd', () => {
    let obj = new MarvellousChkPipe();
    expect(obj.transform(12,'Odd')).toEqual("It is Not a Odd Number");
  });
});
