import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';



describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  });
// Capital And Small Characters:
  it('calculate the Capital & small characters', () => {
    let obj = new AppComponent();
    obj. CountCapital();
    expect(obj.iCnt1).toEqual(2);
    expect(obj.iCnt2).toEqual(5);

  });


  // Check Password
  it('Check Password is Valid or Invalid', () => {
    let obj = new AppComponent();
    obj. ChkPassword();
    expect(obj.chk).toEqual("Valid Password");
  });

    // Array Elements Addition
    it('Addition of Array Elements', () => {
      let obj = new AppComponent();
      obj. ArrayAddition();
      expect(obj.iSum).toEqual(210);
    });
});
