import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Demo';

  str : string = "VaiBhav";
  i  = 0; iCnt1 = 0; iCnt2 = 0;
  CountCapital() : void
  {
    let  Arr = this.str.split("");

    for(this.i = 0; this.i < Arr.length;this.i++)
    {
      if(Arr[this.i] >= 'A' && Arr[this.i] <= 'Z')
      {
        this.iCnt1++;
      }

      if(Arr[this.i] >= 'a' && Arr[this.i] <= 'z')
      {
        this.iCnt2++;
      }
    }
  }

// Array Elements Addition
iSum = 0; j  = 0;
Brr = [10, 20, 30, 40, 50,60];

ArrayAddition(): number
{
  for(this.j = 0; this.j < this.Brr.length; this.j++)
  {
    this.iSum = this.iSum + this.Brr[this.j];
  }
  return this.iSum;
}
//Check Valid Password
chk:string = "";
password : string = "VaiKotK12@202#";
k  = 0; upper = 0; lower = 0; digit = 0; special = 0;

ChkPassword(): string
{
  let  Pass = this.password.split("");
  
  for(this.k = 0; this.k < Pass.length; this.k++)
  {
    if(Pass[this.k] >= 'A' && Pass[this.k] <= 'Z')
    {
      this.upper++;
    }

    else if(Pass[this.k] >= 'a' && Pass[this.k] <= 'z')
    {
      this.lower++;
    }
    else if(Pass[this.k] >= '0' && Pass[this.k] <= '9')
    {
      this.digit++;
    }
    else
    {
      this.special++;
    }
  }
  if(this.upper >= 2 && this.lower >=3 && this.digit >=2 && this.special >= 1 )
  {
    this.chk = "Valid Password"; 
    return this.chk;
  } 
  else
  {
    this.chk = "Invalid Password"; 
    return this.chk;
  }
  }

}
