import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myAdd'
})
export class MyAddPipe implements PipeTransform
 {

  transform(value1: number, value2:number): number
   {
   
   var iNo1:number = value1;
   var iNo2:number = value2;
   var Sum:number = 0; 

    Sum = iNo1 + iNo2;
   
    return Sum;
  }

}
